# EC551 Programming Assignment 1: Logic Synthesis Engine

**Course:** EC551 – Advanced Digital Design with Verilog and FPGAs, Fall 2026  
**Team:** Tanner Armstard and Francis Liri  
**Board:** Digilent Nexys 3, Xilinx Spartan-6 XC6SLX16 in CSG324 package  
**FPGA tools:** Xilinx ISE Design Suite 14.7 WebPACK and iMPACT

## What this project does

The Python program accepts either a single-output SOP expression or a JSON graph of a single-output combinational circuit. It evaluates the function over every input combination, stores its ON-set and OFF-set, computes canonical and minimized forms, reports the requested logic results, and can export structural Verilog and a self-checking testbench.

The included board demo uses `examples/example_circuit.json`, which implements `F = ab + c'`. Three Nexys 3 slide switches control `a`, `b`, and `c`; LD0 displays `F`.

## Project files

```text
.
├── logic_synthesis.py
├── test_logic_synthesis.py
├── nexys3_demo.v
├── nexys3_demo.ucf
├── README.md
└── examples/
    ├── example_circuit.json
    └── logic_function.v
```

`logic_function.v` is the generated single-output circuit for the example. `nexys3_demo.v` is the board-specific top-level wrapper. The `.ucf` file maps the wrapper's switch and LED ports to Nexys 3 pins.

## Run the program

Requires Python 3.9 or newer; only the standard library is used.

```bash
python logic_synthesis.py
```

Choose JSON graph input (`2`) and provide `examples/example_circuit.json`. The menu supports the ten required analysis results, evaluation of one input assignment, truth-table CSV export, report export, and Verilog/testbench export. `a` prints results 1–10 together.

For the example, the minimized SOP is `c' + ab`; the minimized POS is `(b + c') . (a + c')`. Input order is `a,b,c`, with `a` as the most significant truth-table bit.

## Verify the Python program

Run from this directory:

```bash
python -m unittest -v
```

The included six tests cover SOP and JSON inputs, input evaluation, invalid graph references, and the generated Verilog/testbench structure. These Python tests do not replace HDL simulation or FPGA implementation.

## Simulate the generated logic

With Icarus Verilog installed, regenerate `logic_function.v` and `tb_logic_function.v` from the program, then run:

```bash
iverilog -g2012 -s tb_logic_function -o sim.vvp logic_function.v tb_logic_function.v
vvp sim.vvp
```

A successful simulation reports `PASS: all 8 input combinations matched.` The testbench is simulation-only; do not add it to the ISE synthesis sources.

## Nexys 3 hardware demo

The wrapper is the ISE top module. It connects the generated module's ports in the same order as the input declaration: `in_0 = a = SW[0]`, `in_1 = b = SW[1]`, and `in_2 = c = SW[2]`. The generated output `F` drives `LED[0]` (LD0).

1. Create an ISE project for the board's XC6SLX16 FPGA and the correct package/speed grade for the specific board revision.
2. Add `examples/logic_function.v` and `nexys3_demo.v` as Verilog sources; add `nexys3_demo.ucf` as the User Constraints File.
3. Set `nexys3_demo` as the top module.
4. Run Synthesize, Implement Design, and Generate Programming File.
5. Connect the board over USB-JTAG, open iMPACT, identify the FPGA, and program the generated `.bit` file.
6. Toggle SW0–SW2 and compare LD0 against `F = ab + c'` or the truth table below.

| SW2 (`c`) | SW1 (`b`) | SW0 (`a`) | LD0 (`F`) |
|---:|---:|---:|---:|
| 0 | 0 | 0 | 1 |
| 0 | 0 | 1 | 1 |
| 0 | 1 | 0 | 1 |
| 0 | 1 | 1 | 1 |
| 1 | 0 | 0 | 0 |
| 1 | 0 | 1 | 0 |
| 1 | 1 | 0 | 0 |
| 1 | 1 | 1 | 1 |

The physical pin assignments are `SW0=T10`, `SW1=T9`, `SW2=V9`, and `LD0=U16`, with LVCMOS33 I/O standard, based on the Nexys 3 reference manual. Confirm the board revision and device settings in ISE before generating the bitstream.

## Current verification status

- Python syntax and the six included unit tests: verified in the development environment.
- HDL compilation/simulation: not run here because Icarus Verilog is unavailable.
- ISE synthesis/bitstream generation and live Nexys 3 programming: not run here; verify on the target board and ISE installation before presenting hardware results.

## Scope and limitations

- One output and 1–8 inputs; no sequential logic or external don't-care set.
- The JSON input describes one output signal. A multi-output design such as a complete BCD-to-seven-segment decoder needs separate output functions or a different project extension.
- Exact minimization optimizes literal count and then term count; that does not guarantee the smallest FPGA LUT count or best timing.

## AI-use acknowledgment

OpenAI ChatGPT was used to help debug the code and explain how to use the program’s functions and commands. Update this statement if it does not fully describe the assistance used by the team.

## References

- [Digilent Nexys 3 Reference Manual](https://digilent.com/reference/programmable-logic/nexys-3/reference-manual)
- [Xilinx ISE Design Suite 14.7](https://www.amd.com/en/support/downloads/adaptive-socs-and-fpgas/legacy-ise/v2012_4---14_7.html)
