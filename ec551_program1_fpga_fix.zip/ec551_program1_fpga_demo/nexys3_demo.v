// Board-specific top-level wrapper for the example F = ab + c'.
// SW0=a, SW1=b, SW2=c; LD0 displays F.
module nexys3_demo (
    input  wire [2:0] SW,
    output wire [0:0] LED
);
    logic_function u_logic_function (
        .in_0(SW[0]),
        .in_1(SW[1]),
        .in_2(SW[2]),
        .F(LED[0])
    );
endmodule
