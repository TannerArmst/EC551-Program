// Automatically generated minimized SOP circuit.
// in_0 = original input a
// in_1 = original input b
// in_2 = original input c
module logic_function (
    input wire in_0,
    input wire in_1,
    input wire in_2,
    output wire F
);

wire neg_2;
wire term_0;
wire term_1;
not g_not_2 (neg_2, in_2);
buf g_term_0 (term_0, neg_2);
and g_term_1 (term_1, in_0, in_1);
or g_output (F, term_0, term_1);

endmodule
